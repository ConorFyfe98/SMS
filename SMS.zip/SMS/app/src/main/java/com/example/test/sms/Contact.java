package com.example.test.sms;

public class Contact {
    public String name = "";
    public String phoneNumber = "";

    Contact(String n, String pn) {
        name = n;
        phoneNumber = pn;
    }
}

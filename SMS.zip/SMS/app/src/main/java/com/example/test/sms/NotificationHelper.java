package com.example.test.sms;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Build;
import android.support.v4.app.NotificationCompat;

public class NotificationHelper extends ContextWrapper {
    public static final String channelID ="channeID";
    public static final String channelName="channel Name";

    private NotificationManager mManager;

    public NotificationHelper(Context base) {
        super(base);
        //Create a channel for version Oreo or higher. Not required if lower version
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            createChannel();
        }
    }
    @TargetApi(Build.VERSION_CODES.O)
    private void createChannel() {
        //Create new channel, set id, name and level of importance
        NotificationChannel channel = new NotificationChannel(channelID, channelName, NotificationManager.IMPORTANCE_HIGH);

        //Possible set values of notification
        /*channel.enableLights(true);
        channel.enableVibration(true);
        channel.setLightColor(R.color.colorPrimaryDark);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);*/
        getManager().createNotificationChannel(channel);
    }

    public NotificationManager getManager() {
        //If manager is null create a new one, if not use current manager
        if (mManager == null) {
            mManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        }

        return mManager;
    }

    public NotificationCompat.Builder getChannelNotification(String notifyUser, String recepientName, int SmsID) {
        return new NotificationCompat.Builder(getApplicationContext(), channelID)
                //Set title, message and display icon
                .setContentTitle("Scheduled SMS to "+recepientName+SmsID)
                .setContentText(notifyUser)
                .setSmallIcon(R.drawable.ic_message);
    }
}

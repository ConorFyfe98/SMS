package com.example.test.sms;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static java.lang.Boolean.FALSE;

public class pendingTabFragment extends Fragment {
    private static final String TAG = "activity_pending_sms.xml";

    private SmsDatabaseHelper smsDatabaseHelper;
    private ListView list;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_pending_sms,container,false);

        list = (ListView) view.findViewById(R.id.list_sms);

        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                deleteContactAndRefresh(view);
                return true;
            }
        });

        /* Initialise the database our SQLiteOpenHelper object*/
        smsDatabaseHelper = new SmsDatabaseHelper(getContext());

        populateList();
        return view;
    }

    private void populateList() {
        PopulateAsyncTask task = new PopulateAsyncTask();
        task.execute();
    }

    private class PopulateAsyncTask extends AsyncTask<ArrayList<Sms>, Void, SmsAdapter> {
        @Override
        protected SmsAdapter doInBackground(ArrayList<Sms>... string) {
            /* Get contacts list from helper. */
            ArrayList<Sms> sms = smsDatabaseHelper.getSmsList();
            /* Create a list adapter bound to the contacts list. */
            SmsAdapter adapter = new SmsAdapter(getContext(), sms);
            return adapter;
        }

        protected void onPostExecute(SmsAdapter adapter) {
            super.onPostExecute(adapter);
            /* Attach the adapter to our list view. */
            list.setAdapter(adapter);
        }
    }

    private void deleteContactAndRefresh(View view) {
         //Get text values from child views.
        String name = ((TextView) view.findViewById(R.id.display_name)).getText().toString();
        String number = ((TextView) view.findViewById(R.id.display_number)).getText().toString();
        String messageTime = ((TextView) view.findViewById(R.id.display_messageTime)).getText().toString();
        String message = ((TextView) view.findViewById(R.id.display_message)).getText().toString();

        DeleteAsyncTask task = new DeleteAsyncTask();
        task.execute(name, number, messageTime, message);


        // Refresh the list of SMS.
        populateList();
    }



    private class DeleteAsyncTask extends AsyncTask<String, Void, Integer> {
        @Override
        protected Integer doInBackground(String... string) {
            // Construct a Contact object and pass it to the helper for database insertion
            boolean setFalse = FALSE;
            int retrievedID = smsDatabaseHelper.retrieveSmsID(new Sms(string[0], string[1], string[2], string[3], setFalse));
            smsDatabaseHelper.removeSms(retrievedID);

            AlarmManager alarmManager = (AlarmManager) getContext().getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(getContext(), AlertReceiver.class);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), retrievedID, intent,0);

            alarmManager.cancel(pendingIntent);

            return retrievedID;
        }

        protected void onPostExecute(Integer s) {
            super.onPostExecute(s);
            Toast.makeText(getContext(), "ID: "+s, Toast.LENGTH_SHORT).show();

        }
    }
}

package com.example.test.sms;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.telephony.SmsManager;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class AlertReceiver extends BroadcastReceiver {
    public Context context;
    private SmsDatabaseHelper smsDatabaseHelper;
    private int SmsID;

    private BroadcastReceiver sentStatusReceiver, deliveredStatusReceiver;
    @Override
    public void onReceive(Context context, Intent intent) {
        setContext(context);
        smsDatabaseHelper = new SmsDatabaseHelper(context);

        Bundle bundle = intent.getExtras();
        if(bundle != null){
           SmsID = bundle.getInt("SmsID");
        }
        getSmsDetails();
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public void getSmsDetails(){
        ArrayList<Sms> sms = smsDatabaseHelper.getSmsByID(SmsID);
        String number = sms.get(0).number;
        String message = sms.get(0).message;
        String name = sms.get(0).name;
        sendMySMS(number, message, name);
    }

    public void sendMySMS(String phoneNumber, String message, String name){
            SmsManager sms = SmsManager.getDefault();
            List<String> messages = sms.divideMessage(message);
            for (String msg : messages){
                Intent intent = new Intent(getContext(), NotifyUser.class);
                intent.putExtra("name", name);
                intent.putExtra("SmsID",SmsID);
                PendingIntent sentIntent = PendingIntent.getBroadcast(getContext(), SmsID, intent, 0);
                sms.sendTextMessage(phoneNumber, null, msg, sentIntent, null);
            }
        }
    }


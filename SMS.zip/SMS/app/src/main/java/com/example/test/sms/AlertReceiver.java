package com.example.test.sms;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.telephony.SmsManager;
import android.widget.Toast;

import java.util.List;

public class AlertReceiver extends BroadcastReceiver {
    public Context context;
    private BroadcastReceiver sentStatusReceiver, deliveredStatusReceiver;
    @Override
    public void onReceive(Context context, Intent intent) {
        setContext(context);
        sendMySMS();

    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }


    public void sendMySMS(){
            //Assign message variables, these will be retrieved from database
            String phoneNumber="5556";
            String message = "Message will be retrieved from database";
            SmsManager sms = SmsManager.getDefault();
            List<String> messages = sms.divideMessage(message);
            for (String msg : messages){
               //PendingIntent sentIntent = PendingIntent.getBroadcast(this,0, new Intent("SMS_SENT"), 0);
               //PendingIntent deliveredIntent = PendingIntent.getBroadcast(this, 0, new Intent("SMS_DELIVERED"), 0);

               // Intent intent = new Intent(getContext(), NotifyUser.class);
              // PendingIntent sentIntent = PendingIntent.getBroadcast(getContext(), 0, intent, 0);

                sms.sendTextMessage(phoneNumber, null, msg, null, null);

                String notificationMessage="Your message has been..."; // Notification will be assigned based on sentIntent
                sendNotification(notificationMessage);
            }
        }

   public void sendNotification(String notificationMessage){
        NotificationHelper notificationHelper = new NotificationHelper(getContext());
        //Pass notification messsage to channel.
        NotificationCompat.Builder nb = notificationHelper.getChannelNotification(notificationMessage);
        notificationHelper.getManager().notify(1,nb.build());
    }


    }


package com.example.test.sms;


import static java.lang.Boolean.FALSE;

public class Sms {
    public String name = "";
    public String number = "";
    public String messageTime = "";
    public String message = "";
    public boolean messageSent = FALSE;

    Sms(String n, String ln, String mt, String m, boolean f) {
        name = n;
        number = ln;
        messageTime = mt;
        message = m;
        messageSent = f;
    }
}

package com.example.test.sms;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

import static java.lang.Boolean.TRUE;

public class SmsDatabaseHelper extends SQLiteOpenHelper {
    /* Initialise constants. */
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "SMS";
    private static final String SMS_TABLE_NAME = "Messages";
    private static final String[] COLUMN_NAMES = {"SmsID", "Name", "Number", "messageTime", "Message", "messageSent"};
    /* Construct CREATE query string. */
    private static final String SMS_TABLE_CREATE =
            "CREATE TABLE " + SMS_TABLE_NAME + " (" +
                    COLUMN_NAMES[0] + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_NAMES[1] + " TEXT, " +
                    COLUMN_NAMES[2] + " TEXT, " +
                    COLUMN_NAMES[3] + " TEXT, " +
                    COLUMN_NAMES[4] + " TEXT, " +
                    COLUMN_NAMES[5] + " BOOLEAN);";

    SmsDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        // Creates the database if it doesn't exist and adds the "contacts" table.
        /* Execute SQL query. */
        db.execSQL(SMS_TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public int addSms(Sms sms){
        /* Pack contact details in ContentValues object for database insertion. */
        ContentValues row = new ContentValues();
        row.put(this.COLUMN_NAMES[1], sms.name);
        row.put(this.COLUMN_NAMES[2], sms.number);
        row.put(this.COLUMN_NAMES[3], sms.messageTime);
        row.put(this.COLUMN_NAMES[4], sms.message);
        row.put(this.COLUMN_NAMES[5], sms.messageSent);
        // The first parameter is a column name, the second is a value.

        /* Get writable database and insert the new row to the "contacts" table. */
        SQLiteDatabase db = this.getWritableDatabase();
       long longid = db.insert(SMS_TABLE_NAME, null, row);
        db.close();
        int SmsID = (int) longid;
        return SmsID;
    }

    public int getNumberOfSms(){
        /* Query the database and check the number of rows returned. */
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor result = db.query(SMS_TABLE_NAME, COLUMN_NAMES, null, null, null, null, null, null);

        /* Make sure the query returned a valid result before trying to change text on screen.*/
        if(result != null) {
            /* Display result. */
            int contactsCount = result.getCount();
            db.close();
            return contactsCount;
        } else {
            return -1;
        }
    }

    public ArrayList<Sms> getSmsList(){
        /* Get the readable database. */
        SQLiteDatabase db = this.getReadableDatabase();

        /* Get all contacts by querying the database. */
        //Cursor result = db.query(SMS_TABLE_NAME, COLUMN_NAMES, null, null,  null, null, "SmsID DESC", null);
        Cursor result = db.rawQuery("SELECT * FROM Messages WHERE messageSent = 0 ORDER BY SmsID DESC", null);
        /* Convert results to a list of Contact objects. */
        ArrayList<Sms> sms = new ArrayList<Sms>();

        for(int i = 0; i < result.getCount(); i++){
            result.moveToPosition(i);
            /* Create a Contact object with using data from name, email, phone columns. Add it to list. */
            sms.add(new Sms(result.getString(1), result.getString(2), result.getString(3),result.getString(4), result.getInt(5) > 0));
        }
        return sms;
    }

    public ArrayList<Sms> getSentSmsList(){
        /* Get the readable database. */
        SQLiteDatabase db = this.getReadableDatabase();

        /* Get all contacts by querying the database. */
        //Cursor result = db.query(SMS_TABLE_NAME, COLUMN_NAMES, null, null,  null, null, "SmsID DESC", null);
        Cursor result = db.rawQuery("SELECT * FROM Messages WHERE messageSent = 1 ORDER BY SmsID DESC", null);
        /* Convert results to a list of Contact objects. */
        ArrayList<Sms> sms = new ArrayList<Sms>();

        for(int i = 0; i < result.getCount(); i++){
            result.moveToPosition(i);
            /* Create a Contact object with using data from name, email, phone columns. Add it to list. */
            sms.add(new Sms(result.getString(1), result.getString(2), result.getString(3),result.getString(4), result.getInt(5) > 0));
        }
        return sms;
    }


   public ArrayList<Sms> getSmsByID(int searchID){
         //Get the readable database.
        SQLiteDatabase db = this.getReadableDatabase();

         //Get sms by ID
        Cursor result = db.rawQuery("SELECT * FROM Messages WHERE SmsID ="+searchID, null);
         //Convert results to a list of Contact objects.
        ArrayList<Sms> sms = new ArrayList<Sms>();

        for(int i = 0; i < result.getCount(); i++){
            result.moveToPosition(i);
            // Create a Sms object with using data from name, email, phone columns. Add it to list.
            sms.add(new Sms(result.getString(1), result.getString(2), result.getString(3),result.getString(4), result.getInt(5) > 0));
        }

        return sms;
    }

    public int retrieveSmsID(Sms sms){
        SQLiteDatabase db = this.getWritableDatabase();
        String whereClause = "Name = '" + sms.name + "' AND Number = '" + sms.number + "' AND messageTime= '" + sms.messageTime + "' AND message = '" + sms.message + "'";
        // Returns the number of affected rows. 0 means no rows were deleted.
        Cursor result = db.rawQuery("SELECT SmsID FROM Messages WHERE "+whereClause, null);
        int retrievedID = 0;

        for(int i = 0; i < result.getCount(); i++) {
            result.moveToPosition(i);
            retrievedID = result.getInt(0);
        }

        return retrievedID;
    }

    public void removeSms(Integer SmsID){
        SQLiteDatabase db = this.getWritableDatabase();
        String whereClause = "SmsID = '" + SmsID + "'";
        // Returns the number of affected rows. 0 means no rows were deleted.
        db.delete(SMS_TABLE_NAME, whereClause, null);
    }

    public void updateSmsToSent(Integer SmsID){
            int ID = SmsID;
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues cv = new ContentValues();
            cv.put("messageSent", TRUE);
            db.update(SMS_TABLE_NAME,cv, "SmsID="+ID,null);
     }
    }



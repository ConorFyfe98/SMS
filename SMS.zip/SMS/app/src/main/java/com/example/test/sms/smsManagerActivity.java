package com.example.test.sms;

import android.support.design.widget.TabLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class smsManagerActivity extends AppCompatActivity {
    private static final String TAG = "smsManagerActivity";
    private SectionsPageAdapter mSectionPageAdapter;
    private ViewPager mViewPager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_manager);
        Log.d(TAG, "onCreate: Starting.");
        mSectionPageAdapter = new SectionsPageAdapter(getSupportFragmentManager());

        mViewPager = (ViewPager) findViewById(R.id.container);
        setupViewPager(mViewPager);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);
    }

    private void setupViewPager(ViewPager viewPager){
        SectionsPageAdapter adapter =  new SectionsPageAdapter(getSupportFragmentManager());
        adapter.addFragment(new pendingTabFragment(), "Pending");
        adapter.addFragment(new sentTabFragment(), "Sent");
        viewPager.setAdapter(adapter);
    }

}

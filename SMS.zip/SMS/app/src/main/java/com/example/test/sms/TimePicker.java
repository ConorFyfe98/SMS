package com.example.test.sms;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

import static android.Manifest.permission.SEND_SMS;

public class TimePicker extends AppCompatActivity implements TimePickerDialog.OnTimeSetListener{
  private TextView displayTime;
  private EditText messageInput, numberInput;
  private Button selectTimeButton, buttonCancel, scheduleButton;
  public int setHour=-1, setMinute=-1;
    private static final int REQUEST_SMS = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_picker);

        //initialise views
         messageInput = (EditText) findViewById(R.id.messageInput);
         numberInput = (EditText) findViewById(R.id.numberInput);
         displayTime = findViewById(R.id.displayTime);
         selectTimeButton = (Button) findViewById(R.id.selectTimeButton);
         buttonCancel = findViewById(R.id.buttonCancel);
         scheduleButton = findViewById(R.id.scheduleButton);

        //set onClickListener for select Time Button
        selectTimeButton.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                    //Create new time picker from TimePickerFragment.
                DialogFragment timePicker = new TimePickerFragment();
                //Show time picker.
                timePicker.show(getSupportFragmentManager(), "time picker");
            }
        });

        //set onClickListener for cancel button
        buttonCancel.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                cancelAlarm();
            }
        });
        //set onClickListener for schedule button
        scheduleButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                //If build version is marshmallow or higher request run time permission.
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                    //Check permission status of SEND_SMS
                    int hasSMSPermission = checkSelfPermission(SEND_SMS);
                    //If permission is not granted display message informing user the application requires permission
                    if (hasSMSPermission != PackageManager.PERMISSION_GRANTED) {
                        if (!shouldShowRequestPermissionRationale(SEND_SMS)) {

                            showMessageOKCancel("Application requires access to send SMS", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                        requestPermission();
                                    }
                                }
                            });
                            return;
                        }
                        requestPermission();
                        return;
                    }
                    validateInput();
                }

            }
        });
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{SEND_SMS}, REQUEST_SMS);
    }

    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults){
        switch (requestCode){
            case REQUEST_SMS:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    Toast.makeText(getApplicationContext(), "Permission granted, Your text has been scheduled to send.", Toast.LENGTH_SHORT).show();
                    validateInput();
                }else{
                    Toast.makeText(getApplicationContext(), "Permission Denied, You cannot use this feature without granting access.", Toast.LENGTH_SHORT).show();
                    if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                        if(shouldShowRequestPermissionRationale(SEND_SMS)){
                            showMessageOKCancel("You need to allow access to both permissions",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                requestPermissions(new String[]{SEND_SMS},
                                                        REQUEST_SMS);
                                            }
                                        }
                                    });
                            return;
                        }
                    }
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new android.support.v7.app.AlertDialog.Builder(TimePicker.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    private void validateInput(){
        //Assign input to variables
        String phoneNumber = numberInput.getText().toString();
        String message = messageInput.getText().toString();

        if(phoneNumber.isEmpty()) //Ensure phone number is not empty.
        {
            Toast.makeText(getApplicationContext(), "Please enter a valid phone number.", Toast.LENGTH_SHORT).show();

        }else if(message.isEmpty())//Ensure message is not empty.
        {
            Toast.makeText(getApplicationContext(), "Please enter a message.", Toast.LENGTH_SHORT).show();

        }else if(setHour==-1 || setMinute==-1) //Ensure a time has been selected.
        {
            Toast.makeText(getApplicationContext(), "Please select a time", Toast.LENGTH_SHORT).show();
        }else //Inform user message has been scheduled and create calender with input times
        {
            Toast.makeText(getApplicationContext(), "Text has been Scheduled for:"+setHour+":"+setMinute+" Number:"+phoneNumber+" Message:"+message, Toast.LENGTH_SHORT).show();
            createCalendar();
        }
    }


    @Override
    public void onTimeSet(android.widget.TimePicker view, int hourOfDay, int minute) {
        //When user picks time assign Time to variables
      setHour=hourOfDay;
      setMinute=minute;
      //Update the textView to display the time the user has selected
      updateTime();
    }

    private void createCalendar(){
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, setHour);
        c.set(Calendar.MINUTE, setMinute);
        c.set(Calendar.SECOND,0);
        startAlarm(c);
    }

    private void updateTime(){
        //Update textView with time user has selected.
        String timeText = "Alarm set for: ";
        timeText +=setHour+":"+setMinute;
        displayTime.setText(timeText);
    }


    private void startAlarm(Calendar c){
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlertReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 1, intent, 0);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pendingIntent);
    }

    private void cancelAlarm(){
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlertReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 1, intent, 0);

        alarmManager.cancel(pendingIntent);
        displayTime.setText("Cancelled");
    }
}

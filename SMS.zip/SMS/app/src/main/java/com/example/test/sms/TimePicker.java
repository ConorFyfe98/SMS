package com.example.test.sms;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.ContactsContract;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.Calendar;

import static android.Manifest.permission.READ_CONTACTS;
import static android.Manifest.permission.SEND_SMS;
import static android.content.ContentValues.TAG;
import static java.lang.Boolean.FALSE;

public class TimePicker extends AppCompatActivity implements TimePickerDialog.OnTimeSetListener {
    private TextView displayTime;
    private EditText messageInput, numberInput, nameInput;
    private Button selectTimeButton, scheduleButton, contactButton;
    public int setHour = -1, setMinute = -1;
    private int RetrievedSmsID = 1;
    private static final int REQUEST_SMS = 0;
    private static final int REQUEST_READ_CONTACTS = 3;
    float x1, x2, y1, y2;

    private SmsDatabaseHelper smsDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_picker);

        //initialise views
        messageInput = (EditText) findViewById(R.id.messageInput);
        numberInput = (EditText) findViewById(R.id.numberInput);
        nameInput = (EditText) findViewById(R.id.nameInput);
        displayTime = findViewById(R.id.displayTime);
        selectTimeButton = (Button) findViewById(R.id.selectTimeButton);
        scheduleButton = findViewById(R.id.scheduleButton);
        contactButton = (Button) findViewById(R.id.contactButton);

        /* Initialise the database our SQLiteOpenHelper object*/
        smsDatabaseHelper = new SmsDatabaseHelper(this);

        //set onClickListener for select Time Button
        selectTimeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Create new time picker from TimePickerFragment.
                DialogFragment timePicker = new TimePickerFragment();
                //Show time picker.
                timePicker.show(getSupportFragmentManager(), "time picker");
            }
        });


        contactButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {


                //If build version is marshmallow or higher request run time permission.
               if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                    //Check permission status of SEND_SMS
                    int hasSMSPermission = checkSelfPermission(READ_CONTACTS);
                    //If permission is not granted display message informing user the application requires permission
                    if (hasSMSPermission != PackageManager.PERMISSION_GRANTED) {
                        if (!shouldShowRequestPermissionRationale(READ_CONTACTS)) {

                            showMessageOKCancel("Application requires contact access to select contact", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                        requestContactPermission();
                                    }
                                }
                            });
                            return;
                        }
                        requestContactPermission();
                        return;
                    }
                    startActivity(new Intent(TimePicker.this, ContactActivity.class));
                }
                selectContact();

            }
        });


        //set onClickListener for schedule button
        scheduleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //If build version is marshmallow or higher request run time permission.
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                    //Check permission status of SEND_SMS
                    int hasSMSPermission = checkSelfPermission(SEND_SMS);
                    //If permission is not granted display message informing user the application requires permission
                    if (hasSMSPermission != PackageManager.PERMISSION_GRANTED) {
                        if (!shouldShowRequestPermissionRationale(SEND_SMS)) {

                            showMessageOKCancel("Application requires access to send SMS", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                        requestPermission();
                                    }
                                }
                            });
                            return;
                        }
                        requestPermission();
                        return;
                    }
                    validateInput();
                }

            }
        });
    }


    public boolean onTouchEvent(MotionEvent touchEvent) {
        switch (touchEvent.getAction()) {
            //Get X and Y value when user presses finger down on screen
            case MotionEvent.ACTION_DOWN:
                x1 = touchEvent.getX();
                y1 = touchEvent.getY();
                break;
            //Get X and Y value when user lift finger off screen
            case MotionEvent.ACTION_UP:
                x2 = touchEvent.getX();
                y2 = touchEvent.getY();
                //If x value when user lifts finger is less than starting x value, user has swiped left, +500 ensures user has used a long swipe
                if ((x1 - 500) > x2) {
                    Intent intent = new Intent(TimePicker.this, PendingSmsActivity.class);
                    startActivity(intent);
                }
                break;
        }
        return false;
    }

    private void selectContact() {
       Intent pickContact = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
        pickContact.setType(ContactsContract.CommonDataKinds.Phone.CONTENT_TYPE);
       startActivityForResult(pickContact, 1);
        //Intent intent = new Intent(TimePicker.this, ContactActivity.class);
       // startActivity(intent);

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        String selectedName = "";
        String selectedNumber = "";
        // check whether the result is ok
        Uri contactData = data.getData();
        Cursor c = getContentResolver().query(contactData, null, null, null, null);
        if (c.moveToFirst()) {
            int nameIndex = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
            int phoneIndex = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
            selectedName = c.getString(nameIndex);
            selectedNumber = c.getString(phoneIndex);
            updateEnterPhoneNumberEditText(selectedName, selectedNumber);
        }
    }

    private void updateEnterPhoneNumberEditText(String selectedName, String selectedNumber) {
        nameInput.setText(selectedName);
        numberInput.setText(selectedNumber);
    }


    private void requestContactPermission() {
        ActivityCompat.requestPermissions(this, new String[]{READ_CONTACTS}, REQUEST_READ_CONTACTS);
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{SEND_SMS}, REQUEST_SMS);
    }

    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case REQUEST_SMS:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(getApplicationContext(), "Permission granted, Your text has been scheduled to send.", Toast.LENGTH_SHORT).show();
                    validateInput();
                } else {
                    Toast.makeText(getApplicationContext(), "Permission Denied, You cannot schedule an SMS without granting access.", Toast.LENGTH_SHORT).show();
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (shouldShowRequestPermissionRationale(SEND_SMS)) {
                            showMessageOKCancel("You need to allow access to both permissions",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                requestPermissions(new String[]{SEND_SMS},
                                                        REQUEST_SMS);
                                            }
                                        }
                                    });
                            return;
                        }
                    }
                }
                break;

            case REQUEST_READ_CONTACTS:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    Toast.makeText(getApplicationContext(), "Permission granted, You can now select a contact.", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(TimePicker.this, ContactActivity.class));
                }else{
                    Toast.makeText(getApplicationContext(), "Permission Denied, You cannot select a contact without granting access.", Toast.LENGTH_SHORT).show();
                    if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                        if(shouldShowRequestPermissionRationale(READ_CONTACTS)){
                            showMessageOKCancel("You must allow access to both permissions",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                requestPermissions(new String[]{READ_CONTACTS},
                                                        REQUEST_READ_CONTACTS);
                                            }
                                        }
                                    });
                            return;
                        }
                    }
                }
                break;

            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }


    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new android.support.v7.app.AlertDialog.Builder(TimePicker.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    private void validateInput() {
        //Assign input to variables
        String contactName = nameInput.getText().toString();
        String phoneNumber = numberInput.getText().toString();
        String messageText = messageInput.getText().toString();

        if (contactName.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Please enter a name.", Toast.LENGTH_SHORT).show();
        } else if (phoneNumber.isEmpty()) //Ensure phone number is not empty.
        {
            Toast.makeText(getApplicationContext(), "Please enter a valid phone number.", Toast.LENGTH_SHORT).show();

        } else if (messageText.isEmpty())//Ensure message is not empty.
        {
            Toast.makeText(getApplicationContext(), "Please enter a message.", Toast.LENGTH_SHORT).show();

        } else if (setHour == -1 || setMinute == -1) //Ensure a time has been selected.
        {
            Toast.makeText(getApplicationContext(), "Please select a time", Toast.LENGTH_SHORT).show();
        } else //Inform user message has been scheduled and create calender with input times
        {
            Toast.makeText(getApplicationContext(), "Text has been Scheduled for:" + setHour + ":" + setMinute + " Number:" + phoneNumber + " Message:" + messageText, Toast.LENGTH_SHORT).show();
            //createCalendar();
            addToSms(contactName, phoneNumber, messageText);
        }
    }


    private void checkNumberOfSms() {
        int smsCount = smsDatabaseHelper.getNumberOfSms();

        if (smsCount == -1) {
            Toast.makeText(TimePicker.this, "No database", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(TimePicker.this, "Database Exists", Toast.LENGTH_SHORT).show();
        }
    }

    public void addToSms(String contactName, String phoneNumber, String messageText) {
        String name = contactName;
        String number = phoneNumber;
        String message = messageText;
        String messageTime = Integer.toString(setHour) +":"+ Integer.toString(setMinute);
        boolean setFalse = FALSE;

       // smsDatabaseHelper.addSms(new Sms(name, number, message, messageTime, setFalse));
      // checkNumberOfSms();
      //  Toast.makeText(TimePicker.this, "Success", Toast.LENGTH_SHORT).show();
        //createCalendar();

        ExampleAsyncTask task = new ExampleAsyncTask();
        task.execute(name, number, messageTime, message);

    }

    private class ExampleAsyncTask extends AsyncTask<String, Void, Integer> {
        @Override
        protected Integer doInBackground(String... string) {
            boolean setFalse = FALSE;
             //Construct a Sms object and pass it to the helper for database insertion
            int SmsID =  smsDatabaseHelper.addSms(new Sms(string[0], string[1], string[2], string[3], setFalse));
         return SmsID;
        }

       protected void onPostExecute(Integer SmsID){
            super.onPostExecute(SmsID);
            checkNumberOfSms();
            Toast.makeText(TimePicker.this, ""+SmsID, Toast.LENGTH_SHORT).show();
           setRetrievedSmsID(SmsID);
           startAlarm();
            resetInput();
        }
    }

    public void setRetrievedSmsID(int SmsID) {
        this.RetrievedSmsID = SmsID;
    }

    public int getRetrievedSmsID() {
        return RetrievedSmsID;
    }

    private void resetInput(){
        nameInput.setText("");
        numberInput.setText("");
        messageInput.setText("");
        displayTime.setText("No Time Selected");
    }


    @Override
    public void onTimeSet(android.widget.TimePicker view, int hourOfDay, int minute) {
        //When user picks time assign Time to variables
      setHour=hourOfDay;
      setMinute=minute;
      //Update the textView to display the time the user has selected
      updateTime();
    }


    private void updateTime(){
        //Update textView with time user has selected.
        //int addZero = 0;

        /*if(setHour <=9){
            String joinedIntegers = Integer.toString(addZero) + Integer.toString(setHour);
            setHour = Integer.parseInt(joinedIntegers);
        }

        if(setMinute <=9){
            String joinedIntegers = Integer.toString(addZero) + Integer.toString(setMinute);
            setMinute = Integer.parseInt(joinedIntegers);
        }*/

        String timeText = "Alarm set for: ";
        timeText +=setHour+":"+setMinute;
        displayTime.setText(timeText);
    }

    private void startAlarm(){
        StartAlarmAsyncTask task = new StartAlarmAsyncTask();
        task.execute(setHour, setMinute);
    }

    private class StartAlarmAsyncTask extends AsyncTask<Integer, Void, String> {
        @Override
        protected String doInBackground(Integer... time) {
            String result="SMS Successfully Scheduled";
            //Construct a Sms object and pass it to the helper for database insertion
            try {
                Calendar c = Calendar.getInstance();
                c.set(Calendar.HOUR_OF_DAY, time[0]);
                c.set(Calendar.MINUTE, time[1]);
                c.set(Calendar.SECOND,0);

                //Unique number to be retrieved from database
                AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                Intent intent = new Intent(getApplicationContext(), AlertReceiver.class);
                intent.putExtra("SmsID", getRetrievedSmsID());
                PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), getRetrievedSmsID(), intent, 0);
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pendingIntent);
            } catch (Exception e) {
                e.printStackTrace();
                result = "SMS failed to schedule: Alarm manager error";
            }
            return result;
        }

        protected void onPostExecute(String SmsID){
            super.onPostExecute(SmsID);
            checkNumberOfSms();
            Toast.makeText(TimePicker.this, "Result"+SmsID, Toast.LENGTH_SHORT).show();
        }
    }


}

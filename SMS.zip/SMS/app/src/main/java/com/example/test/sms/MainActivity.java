package com.example.test.sms;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import java.util.List;

import static android.Manifest.permission.SEND_SMS;
import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button newSmsButton, smsManagerButton;
    private Switch notificationsSwitch;
    public static Boolean notificationsOn = TRUE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        newSmsButton = (Button) findViewById(R.id.newSmsButton);
        newSmsButton.setOnClickListener(this);

        smsManagerButton = (Button) findViewById(R.id.smsManagerButton);
        smsManagerButton.setOnClickListener(this);

        notificationsSwitch = (Switch) findViewById(R.id.notificationsSwitch);
        SharedPreferences settings = getSharedPreferences("switchStaus", 0);
        boolean silent = settings.getBoolean("switchkey", false);

        notificationsSwitch.setChecked(silent);
        notificationsSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (notificationsSwitch.isChecked()){
                    notificationsOn = TRUE;
                    Toast.makeText(getApplicationContext(), "Notifications turned on", Toast.LENGTH_SHORT).show();
                }else{
                    notificationsOn = FALSE;
                    Toast.makeText(getApplicationContext(), "Notifications turned off", Toast.LENGTH_SHORT).show();
                }
                SharedPreferences settings = getSharedPreferences("switchStaus", 0);
                SharedPreferences.Editor editor = settings.edit();
                editor.putBoolean("switchkey", isChecked);
                editor.commit();
            }
        });

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.newSmsButton:
                Intent intentNewSms = new Intent(MainActivity.this, TimePicker.class);
                intentNewSms.putExtra("notificationsStatus", notificationsOn);
                startActivity(intentNewSms);
                break;

            case R.id.smsManagerButton:
                Intent intentSmsManager = new Intent(MainActivity.this, PendingSmsActivity.class);
                startActivity(intentSmsManager);
                break;

            default:
                break;
        }
    }



}

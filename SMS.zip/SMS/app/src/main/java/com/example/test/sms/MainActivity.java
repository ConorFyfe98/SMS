package com.example.test.sms;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

import static android.Manifest.permission.SEND_SMS;

public class MainActivity extends AppCompatActivity {

    private EditText messageInput, numberInput;
    private Button sendButton, contactButton;
    private BroadcastReceiver sentStatusReceiver, deliveredStatusReceiver;
    private static final int REQUEST_SMS = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialise views
        messageInput = (EditText) findViewById(R.id.messageInput1);
        numberInput = (EditText) findViewById(R.id.numberInput);
        sendButton = (Button) findViewById(R.id.sendButton);
        contactButton = (Button) findViewById(R.id.contactButton);

        //set onClickListener
        sendButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.sendButton:
                        //If build version is marshmallow or higher request run time permission.
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        //Check permission status of SEND_SMS
                        int hasSMSPermission = checkSelfPermission(SEND_SMS);
                        //If permission is not granted display message informing user the application requires permission
                        if (hasSMSPermission != PackageManager.PERMISSION_GRANTED) {
                            if (!shouldShowRequestPermissionRationale(SEND_SMS)) {

                                showMessageOKCancel("Application requires access to send SMS", new DialogInterface.OnClickListener() {
                                    //If user selects ok, request permission to sent SMS
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                            requestPermission();
                                        }
                                    }
                                });
                                return;
                            }
                            requestPermission();
                            return;
                        }
                        sendMySMS();
                    }
                    break;

                    case R.id.contactButton:
                        startActivity(new Intent(MainActivity.this, ContactActivity.class));
                        break;

                }
            }
        });
    }

    public void sendMySMS(){
        //Assign input to variables
        String phoneNumber = numberInput.getText().toString();
        String message = messageInput.getText().toString();

        //Validate number and message
        if(phoneNumber.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Please enter a valid phone number.", Toast.LENGTH_SHORT).show();

        }else if(message.isEmpty()){
            Toast.makeText(getApplicationContext(), "Please enter a message.", Toast.LENGTH_SHORT).show();
        }else{
            SmsManager sms = SmsManager.getDefault();
            //Divide message is the message is too long.
            List<String> messages = sms.divideMessage(message);
            //Loop to send messages
            for (String msg : messages){
                //Use getBroadcast to track the SMS
                PendingIntent sentIntent = PendingIntent.getBroadcast(this, 0, new Intent("SMS_SENT"), 0);
                PendingIntent deliveredIntent = PendingIntent.getBroadcast(this, 0, new Intent("SMS_DELIVERED"), 0);
                sms.sendTextMessage(phoneNumber, null, msg, sentIntent, deliveredIntent);
            }
        }

    }

    public void onResume() {
        super.onResume();
        sentStatusReceiver= new BroadcastReceiver() {
            //Receive Sent Status
            @Override
            public void onReceive(Context arg0, Intent arg1) {
                //Assign message to unknown error.
                String messageSentStatus = "Unknown Error";
               //Assign appropriate message to based on result code
                switch (getResultCode()) {
                    case Activity.RESULT_OK:
                        messageSentStatus = "Message has been sent.";
                        break;
                    case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                        messageSentStatus = "Message could not be sent.\nGeneric Failure Error";
                        break;
                    case SmsManager.RESULT_ERROR_NO_SERVICE:
                        messageSentStatus = "Message could not be sent.\nNo Service Available";
                        break;
                    case SmsManager.RESULT_ERROR_NULL_PDU:
                        messageSentStatus = "Message could not be sent.\nNull PDU";
                        break;
                    case SmsManager.RESULT_ERROR_RADIO_OFF:
                        messageSentStatus = "Message could not be sent.\nRadio is off";
                        break;
                    default:
                        break;
                }
                //Display message status
                Toast.makeText(getApplicationContext(), messageSentStatus, Toast.LENGTH_SHORT).show();

            }
        };
        deliveredStatusReceiver = new BroadcastReceiver() {

            @Override
            public void onReceive(Context arg0, Intent arg1) {
                //Assign message to not delivered.
                String messageDeliveredStatus = "Message Not Delivered";
                //Assign appropriate message to based on result code
                switch(getResultCode()) {
                    case Activity.RESULT_OK:
                        messageDeliveredStatus = "Message Delivered.";
                        break;
                    case Activity.RESULT_CANCELED:
                        break;
                }
                //Clear Input
                numberInput.setText("");
                messageInput.setText("");
                //Display message status
                Toast.makeText(getApplicationContext(), messageDeliveredStatus, Toast.LENGTH_SHORT).show();
            }
        };
        registerReceiver(sentStatusReceiver, new IntentFilter("SMS_SENT"));
        registerReceiver(deliveredStatusReceiver, new IntentFilter("SMS_DELIVERED"));
   }

    public void onPause(){
        super.onPause();
        unregisterReceiver(sentStatusReceiver);
        unregisterReceiver(deliveredStatusReceiver);
    }

    private boolean checkPermission(){
        return (ContextCompat.checkSelfPermission(getApplicationContext(), SEND_SMS) == PackageManager.PERMISSION_GRANTED);
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{SEND_SMS}, REQUEST_SMS);
    }

    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults){
        switch (requestCode){
            case REQUEST_SMS:
                //Check grant result is permission granted, If the permission is granted, inform user they may send SMS.
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    Toast.makeText(getApplicationContext(), "Permission Granted, you can access sms", Toast.LENGTH_SHORT).show();
                    sendMySMS();
                }else{
                    //If user denies permission inform them they
                    if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                        if(shouldShowRequestPermissionRationale(SEND_SMS)){
                            //Inform user that they must allow permissions to use the application
                            showMessageOKCancel("You must allow access to permissions to use the SMS feature",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                               // requestPermissions(new String[]{SEND_SMS},
                                                 //       REQUEST_SMS);
                                                requestPermission();
                                            }
                                        }
                                    });
                            return;
                        }
                    }
                }
                break;
                default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new android.support.v7.app.AlertDialog.Builder(MainActivity.this)
                //Display message with options to Cancel or Select OK
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }
}

package com.example.test.sms;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static java.lang.Boolean.FALSE;

public class PendingSmsActivity extends AppCompatActivity {

    private SmsDatabaseHelper smsDatabaseHelper;
    private ListView list;
    float x1, x2, y1, y2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending_sms);

        list = (ListView) findViewById(R.id.list_sms);


        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                deleteContactAndRefresh(view);
                return true;
            }
        });

        /* Initialise the database our SQLiteOpenHelper object*/
        smsDatabaseHelper = new SmsDatabaseHelper(this);

        populateList();
    }

    //NEED TO IMPLEMENT PROPERLY!
    public boolean onTouchEvent(MotionEvent touchEvent) {
        switch (touchEvent.getAction()) {
            //Get X and Y value when user presses finger down on screen
            case MotionEvent.ACTION_DOWN:
                x1 = touchEvent.getX();
                y1 = touchEvent.getY();
                break;
            //Get X and Y value when user lift finger off screen
            case MotionEvent.ACTION_UP:
                x2 = touchEvent.getX();
                y2 = touchEvent.getY();
                //If x value when user lifts finger is more than starting x value, user has swiped right, +500 ensures user has used a long swipe
                if ((x1 - 500) > x2) {
                    Intent intent = new Intent(PendingSmsActivity.this, TimePicker.class);
                    startActivity(intent);
                }
                break;
        }
        return false;
    }


    private void populateList() {
        PopulateAsyncTask task = new PopulateAsyncTask();
        task.execute();
    }

    private class PopulateAsyncTask extends AsyncTask<ArrayList<Sms>, Void, SmsAdapter> {
        @Override
        protected SmsAdapter doInBackground(ArrayList<Sms>... string) {
            /* Get contacts list from helper. */
            ArrayList<Sms> sms = smsDatabaseHelper.getSmsList();
            /* Create a list adapter bound to the contacts list. */
            SmsAdapter adapter = new SmsAdapter(getApplicationContext(), sms);
            return adapter;
        }

        protected void onPostExecute(SmsAdapter adapter) {
            super.onPostExecute(adapter);
            /* Attach the adapter to our list view. */
            list.setAdapter(adapter);
        }
    }

    private void deleteContactAndRefresh(View view) {
        /* Get text values from child views. */
        String name = ((TextView) view.findViewById(R.id.display_name)).getText().toString();
        String number = ((TextView) view.findViewById(R.id.display_number)).getText().toString();
        String messageTime = ((TextView) view.findViewById(R.id.display_messageTime)).getText().toString();
        String message = ((TextView) view.findViewById(R.id.display_message)).getText().toString();

        DeleteAsyncTask task = new DeleteAsyncTask();
        task.execute(name, number, messageTime, message);


        /* Refresh the list of contacts. */
        populateList();
    }

    private class DeleteAsyncTask extends AsyncTask<String, Void, Integer> {
        @Override
        protected Integer doInBackground(String... string) {
            /* Construct a Contact object and pass it to the helper for database insertion */
            boolean setFalse = FALSE;
            int retrievedID = smsDatabaseHelper.retrieveSmsID(new Sms(string[0], string[1], string[2], string[3], setFalse));
            smsDatabaseHelper.removeSms(retrievedID);

            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(getApplicationContext(), AlertReceiver.class);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), retrievedID, intent,0);

            alarmManager.cancel(pendingIntent);

            return retrievedID;
        }

        protected void onPostExecute(Integer s) {
            super.onPostExecute(s);
            Toast.makeText(PendingSmsActivity.this, "ID: "+s, Toast.LENGTH_SHORT).show();

        }

    }
}
